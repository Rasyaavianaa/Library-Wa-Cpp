<div align="center">
  <img src="assets/banner.png" alt="WACPP2 — WhatsApp C++ Library" width="100%" />
  <br />
  <img src="assets/logo.png" alt="Logo WACPP2" width="112" />
  <h1>🌈 WACPP2 — WhatsApp C++ Library</h1>
  <p><b>Simple API · Powerful · Fast · Open Source</b></p>
  <p><i>Ngoding C++, ngobrol sama protokol WhatsApp. Pelan-pelan, tapi jalan terus. 🚀</i></p>
  <p>
    <img src="https://img.shields.io/badge/Language-C%2B%2B2c-00c9ff?style=for-the-badge" alt="C++2c" />
    <img src="https://img.shields.io/badge/Project-Early%20Stage-ff4fd8?style=for-the-badge" alt="Early stage" />
    <img src="https://img.shields.io/badge/Platform-Linux-8b5cf6?style=for-the-badge" alt="Linux" />
    <img src="https://img.shields.io/badge/Focus-Library-22c55e?style=for-the-badge" alt="Library" />
  </p>
  <p><b>Viana Studio© By Rasya</b></p>
</div>

---

## ✨ Kenalan dulu sama WACPP2

WACPP2 itu project **library WhatsApp berbasis C++**. Jadi fokusnya bukan nyediain bot WhatsApp siap pakai, bukan juga platform bot tinggal klik terus langsung jadi. Kita nyediain fondasi library dan komponen protokol yang bisa dipelajari atau diintegrasikan ke aplikasi C++ lain.

Intinya, project ini dibuat buat yang pengin ngulik komunikasi WhatsApp dari sisi C++ native: mulai dari koneksi WebSocket, proses handshake, encoding node biner, pengelolaan kredensial, sampai jalur enkripsi dan pemrosesan pesan.

Bahasanya simpel: ini masih fondasi. Bukan project yang mau sok bilang semuanya udah sempurna. Masih tahap awal, masih terus berkembang, dan kompatibilitasnya bisa ikut berubah kalau protokol WhatsApp berubah. Jadi pantengin perkembangan repo-nya, ya. 🌱

> ⚠️ **Biar nggak salah paham:** WACPP2 adalah library, bukan layanan bot WhatsApp. Repo ini menyediakan kode dasar dan runtime/demo kecil buat pengujian. Kamu tetap perlu bikin aplikasi sendiri di atas library ini sesuai kebutuhanmu.

## 🌈 Kenapa dibikin?

C++ punya performa dan kontrol yang menarik buat pengembangan aplikasi native. Di sisi lain, integrasi ke protokol WhatsApp punya banyak bagian teknis yang perlu ditangani dengan rapi. WACPP2 mencoba merapikan bagian-bagian itu ke dalam modul C++ yang bisa dibaca dan dikembangkan.

Project ini dikerjakan secara mandiri oleh **1 orang developer** dengan waktu pengerjaan sekitar **1 minggu 3 hari**. Jadi jangan dibandingin sama library yang udah dikembangin tim gede bertahun-tahun, wkwk. Yang penting fondasinya terus dibangun, dites, dan diperbaiki.

## 🚀 Gambaran fitur yang ada di source saat ini

| 🌟 Bagian | 🧩 Peran di library |
|---|---|
| 🔌 WebSocket + TLS | Koneksi ke endpoint WebSocket dengan TLS melalui OpenSSL. |
| 🤝 Noise handshake | Struktur proses handshake Noise untuk membangun kanal komunikasi terenkripsi. |
| 📦 WABinary codec | Membuat, encode, decode, dan menampilkan struktur node biner. |
| 🔐 Crypto utilities | Utilitas hash, HMAC, HKDF, PBKDF2, AES, dan operasi kunci X25519. |
| 🪪 Pairing & credentials | Membuat, membaca, dan menyimpan material kredensial untuk proses pairing/login. |
| 🔑 Signal layer | Pengelolaan prekey dan sesi Signal, termasuk alur X3DH dan Double Ratchet. |
| 💬 Message parser | Membaca struktur protobuf pesan dan mengambil informasi pesan teks yang dikenali. |
| 📤 Outbound helpers | Helper JID, pembuatan payload pesan teks, padding, dan persiapan data keluar. |
| 🧰 Client API | Mengatur lifecycle koneksi, callback, antrean pesan keluar, dan penerimaan pesan. |
| 🧪 Self-test | Kumpulan tes internal untuk beberapa bagian codec, crypto, pairing, pesan, dan sesi. |

> Catatan ya: daftar di atas menjelaskan modul yang memang terlihat di source sekarang, bukan janji bahwa seluruh fitur WhatsApp sudah didukung penuh. Dukungan media, grup, dan perilaku protokol tertentu masih perlu pengujian serta pengembangan lebih lanjut.

## 🧠 Isi library-nya ngapain aja?

### 1. 🔌 WebSocket client

Modul `ws` menangani koneksi WebSocket di atas TLS. Opsi koneksi mencakup header tambahan, timeout koneksi/handshake, dan verifikasi TLS. Data bisa dikirim sebagai frame biner atau teks, lalu diterima melalui fungsi `receive()`.

### 2. 🤝 Noise session

Modul `noise` berisi bagian handshake yang digunakan client untuk memulai sesi terenkripsi. Di dalam prosesnya ada pembuatan ephemeral key, pemrosesan server hello, penggabungan material kunci, dan enkripsi payload handshake.

### 3. 📦 WABinary

WhatsApp menggunakan representasi node biner untuk banyak struktur protokol. Modul `binary` menyediakan struktur `Node`, daftar atribut, child node, encode, decode, dan dump untuk membantu pemeriksaan struktur saat debugging.

Contoh bentuk node dari API:

```cpp
#include "wa/binary.hpp"

using namespace wa::binary;

Node node = make_node(
    "iq",
    {{"to", "s.whatsapp.net"}, {"type", "get"}, {"id", "12345"}}
);

Bytes encoded = encode(node);
auto decoded = decode(encoded);
```

Potongan ini hanya menunjukkan pemakaian codec node; bukan contoh login atau pengiriman pesan ke WhatsApp.

### 4. 🔐 Cryptography

Modul `crypto` menyediakan helper untuk operasi kriptografi yang dipakai modul lain, termasuk random bytes, SHA-1, SHA-256, HMAC-SHA256, HKDF-SHA256, PBKDF2-SHA256, AES-GCM, AES-CTR, AES-CBC, dan X25519.

Modul `xeddsa` menyediakan fungsi tanda tangan dan verifikasi yang dibutuhkan pada alur tertentu. Implementasi ini menggunakan OpenSSL dan libsodium sesuai bagian source masing-masing.

### 5. 🪪 Credentials & pairing

`Creds` menyimpan material seperti key pair, signed prekey, registration ID, pairing code, dan identitas akun. Fungsi `generate_creds()`, `save_creds()`, serta `load_creds()` mengelola pembuatan dan penyimpanan data tersebut.

**Penting banget:** file kredensial bukan file biasa. Di dalamnya ada material privat yang bisa berkaitan langsung dengan sesi akun. Jangan upload `creds.txt`, jangan kirim ke orang lain, dan jangan masukin ke commit publik.

### 6. 🔑 Signal store

Modul `signal` mengelola prekey serta state sesi per alamat/JID. Bagian `Cipher` menyiapkan fungsi enkripsi/dekripsi pesan dan inisialisasi sesi keluar menggunakan prekey bundle.

File penyimpanan Signal juga bersifat privat. Kalau file ini hilang, state sesi yang tersimpan bisa ikut hilang dan aplikasi mungkin perlu membangun sesi lagi.

### 7. 💬 Message & outbound

Modul `message` menangani unpadding serta pembacaan protobuf pesan. Struktur `IncomingMessage` menampung beberapa informasi seperti ID, alamat chat, author, timestamp, jenis pesan, teks, dan data mentah.

Modul `outbound` berisi helper untuk normalisasi dan pemisahan JID, pembuatan ID pesan, payload teks, padding, serta helper untuk beberapa query/prekey yang diperlukan di jalur pengiriman.

### 8. 🧰 Client API

Class `wa::Client` menjadi penghubung beberapa modul tadi. Konfigurasi utamanya ada di `wa::ClientConfig`, sedangkan fungsi `run()` menjalankan alur client secara blocking. Pesan keluar bisa dimasukkan lewat `enqueue_text()` dan diproses oleh event loop.

Callback yang tersedia di konfigurasi:

- `on_pairing_code`: menerima kode pairing saat proses pairing.
- `on_message`: dipanggil saat ada pesan masuk yang sudah diproses.
- `on_ready`: dipanggil setelah login berhasil pada mode `stay_online`.

## 🗂️ Struktur repository

```text
WACPP2/
├── assets/
│   ├── banner.png          # Banner resmi dari project
│   └── logo.png            # Ikon WACPP2 dari banner
├── include/
│   └── wa/                 # Header / API publik library
│       ├── binary.hpp
│       ├── client.hpp
│       ├── common.hpp
│       ├── creds.hpp
│       ├── crypto.hpp
│       ├── message.hpp
│       ├── noise.hpp
│       ├── outbound.hpp
│       ├── pairing.hpp
│       ├── payload.hpp
│       ├── signal.hpp
│       ├── tokens.inc
│       ├── ws.hpp
│       └── xeddsa.hpp
├── src/                    # Implementasi C++
├── tools/
│   └── gen_tokens.py       # Generator tabel token WABinary
├── .gitignore
├── Makefile
└── README.md
```

Folder `build/`, `creds.txt`, dan `signal.txt` memang tidak disertakan di repo publik. Folder build bisa dibuat lagi saat kompilasi, sedangkan dua file lainnya akan dibuat/dipakai oleh runtime dan harus tetap privat.

## ⚙️ Persiapan sebelum build

Project ini ditujukan untuk lingkungan Linux dan membutuhkan toolchain yang mendukung mode bahasa **C++2c** serta library eksternal berikut:

| 📦 Dependency | Dipakai untuk |
|---|---|
| `clang++` | Kompilasi C++. |
| `make` | Menjalankan build berdasarkan Makefile. |
| `OpenSSL` development package | TLS dan operasi kriptografi. |
| `libsodium` development package | Fungsi pendukung XEdDSA. |
| `zlib` development package | Kompresi/dekompresi data. |

Contoh instalasi dependency di Debian/Ubuntu:

```bash
sudo apt update
sudo apt install clang make libssl-dev libsodium-dev zlib1g-dev
```

Pastikan compiler dan standard library yang dipakai sudah mendukung fitur C++2c, `std::expected`, dan `std::format`. Kebutuhan versi toolchain bisa berbeda tergantung distro yang dipakai.

## 🛠️ Build dari source

Clone repository:

```bash
git clone <URL-REPOSITORY-KAMU>
cd WACPP2
```

Build:

```bash
make -j"$(nproc)" \
  CXXFLAGS="-std=c++2c -O2 -Wall -Wextra -Iinclude -include cstring"
```

Flag `-include cstring` dipakai sebagai workaround build untuk deklarasi `std::memcpy` yang belum di-include langsung di salah satu source. Source sengaja tidak disentuh di bagian itu agar perubahan tetap terbatas sesuai permintaan. Kalau berhasil, executable akan dibuat di:

```text
build/wacpp2
```

Untuk mengulang kompilasi dari awal:

```bash
make clean
make -j"$(nproc)" \
  CXXFLAGS="-std=c++2c -O2 -Wall -Wextra -Iinclude -include cstring"
```

## 🧪 Menjalankan self-test

Setelah build berhasil, jalankan:

```bash
./build/wacpp2 selftest
```

Alias yang tersedia:

```bash
./build/wacpp2 cpp selftest
```

Tes internal ini memeriksa beberapa jalur seperti codec, fungsi crypto, pembuatan pairing code, tanda tangan, parsing pesan, penyimpanan sesi, dan pertukaran pesan terenkripsi antar dua state uji. Lulus self-test bukan berarti seluruh koneksi ke layanan WhatsApp dijamin berhasil; pengujian jaringan tetap bergantung pada versi protokol dan kondisi layanan.

## 🧩 Contoh integrasi API C++

Ini gambaran minimal cara menyiapkan `ClientConfig`. Sesuaikan versi protokol dan callback berdasarkan kebutuhan aplikasi yang kamu bangun.

```cpp
#include <iostream>
#include <utility>

#include "wa/client.hpp"
#include "wa/payload.hpp"

int main() {
    wa::ClientConfig config;

    auto version = wa::parse_version("2.3000.REV");
    if (!version) {
        std::cerr << version.error().message << '\n';
        return 1;
    }

    config.version = *version;
    config.phone = "628xxxxxxxxxx"; // isi sendiri saat pairing pertama
    config.creds_path = "creds.txt";
    config.store_path = "signal.txt";

    config.on_pairing_code = [](std::string_view code) {
        std::cout << "Pairing code: " << code << '\n';
    };

    config.on_message = [](const wa::IncomingMessage& message) {
        std::cout << "Pesan masuk dari: " << message.from << '\n';
        if (!message.text.empty()) {
            std::cout << message.text << '\n';
        }
    };

    wa::Client client(std::move(config));
    auto result = client.run();
    if (!result) {
        std::cerr << result.error().message << '\n';
        return 1;
    }
    return 0;
}
```

> `2.3000.REV` di atas adalah contoh format, bukan jaminan versi yang selalu valid. Isi dengan versi client yang sesuai dengan protokol yang sedang dipakai dan diuji.

## 🖥️ Mode CLI yang tersedia

Executable juga membawa jalur CLI untuk membantu pairing, handshake, serta self-test. Tampilkan petunjuk dasar dengan:

```bash
./build/wacpp2
./build/wacpp2 cpp help
```

Contoh bentuk perintah pairing:

```bash
./build/wacpp2 pair \
  --version 2.3000.REV \
  --phone 628xxxxxxxxxx
```

Mode `cpp start` menjalankan runtime yang tetap aktif:

```bash
./build/wacpp2 cpp start \
  --version 2.3000.REV \
  --phone 628xxxxxxxxxx
```

Opsi penyimpanan bisa diarahkan ke lokasi sendiri menggunakan `--creds` dan `--store`. Opsi pairing code kustom tersedia lewat `--code` jika memang dibutuhkan dan valid menurut aturan kode di library.

Sekali lagi: CLI ini bukan produk bot siap pakai. Tujuannya sebagai jalur runtime/demo untuk membantu pengujian komponen client.

## 🔒 Keamanan data akun — baca dulu, jangan diskip

WACPP2 menyimpan material yang sensitif untuk mempertahankan sesi. Beberapa hal yang wajib dijaga:

1. **Jangan pernah commit `creds.txt` atau `signal.txt`.** Keduanya masuk daftar `.gitignore`.
2. Jangan tempel pairing code, private key, atau isi file sesi ke issue publik, screenshot, chat grup, maupun repo.
3. Gunakan perangkat dan direktori yang aksesnya kamu kontrol.
4. Jangan membagikan salinan sesi ke orang lain hanya karena mereka ingin mencoba library.
5. Untuk mencoba dari awal, jalankan runtime tanpa membawa file sesi milik akun lain.

File sesi yang dibagikan bisa membuka risiko terhadap akun. Repo ini sengaja hanya membawa source, header, tool, dokumentasi, serta aset visual — bukan kredensial akun siapa pun.

## 🧭 Status pengembangan

<details>
  <summary>📍 Status sekarang — masih tahap awal</summary>

  - Struktur library C++ sudah tersedia.
  - Modul koneksi, codec, crypto, pairing, Signal, dan client sudah ada di source.
  - Self-test internal tersedia melalui perintah `selftest`.
  - Kompatibilitas protokol masih perlu dipantau dan diuji berkala.
  - Fitur yang belum teruji penuh tidak dianggap stabil atau siap produksi.

</details>

Project ini **masih tahap awal**. Jangan anggap semua bagian sudah final, ya. Feedback, laporan bug yang jelas, dan kontribusi yang relevan bakal sangat membantu perkembangan library.

**Catatan lisensi:** source disiapkan untuk dilihat publik, tetapi file `LICENSE` belum ditentukan di repo ini. Jangan mengasumsikan izin redistribusi atau penggunaan komersial tertentu sampai lisensinya ditetapkan.

## 🧑‍💻 Tentang pengembang

| 👤 Info | Detail |
|---|---|
| Developer | Rasya |
| Tim | 1 orang |
| Waktu pengerjaan | 1 minggu 3 hari |
| Studio / branding | Viana Studio© By Rasya |
| Fokus project | WhatsApp C++ Library |
| Tahap | Early stage / pengembangan awal |

## 📮 Kontak

Ada pertanyaan soal source, nemu bug, atau mau ngobrolin kontribusi? Hubungi lewat:

- 📧 **Email:** [rasyaatdia@gmail.com](mailto:rasyaatdia@gmail.com)
- 📱 **WhatsApp:** [+62 857-3807-4528](https://wa.me/6285738074528)

## ⭐ Support project

Kalau project ini menarik buat kamu, bantu dengan cara yang simpel:

- ⭐ Kasih star ke repository.
- 🐛 Laporkan bug dengan detail langkah reproduksi dan log yang sudah disensor.
- 🧪 Uji di environment masing-masing tanpa membagikan kredensial atau data sesi.
- 💡 Kasih saran yang relevan dengan pengembangan library.

Jangan kirim private key, pairing code, nomor pribadi orang lain, atau file sesi saat bikin issue. Sensor dulu semua informasi sensitifnya.

---

<div align="center">
  <h3>🌈 Small Library, Big Possibilities ✨</h3>
  <p>Masih awal, masih belajar, masih dikembangin.</p>
  <p><b>WACPP2 — WhatsApp C++ Library</b></p>
  <p><b>Viana Studio© By Rasya</b></p>
</div>
