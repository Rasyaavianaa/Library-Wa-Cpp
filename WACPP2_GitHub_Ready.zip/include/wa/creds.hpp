#pragma once

#include <optional>
#include <string>

#include "wa/common.hpp"
#include "wa/crypto.hpp"

namespace wa {

struct Creds {
    crypto::KeyPair noise_key;          // kunci statis Noise
    crypto::KeyPair identity_key;       // signedIdentityKey (X25519)
    crypto::KeyPair pairing_ephemeral;  // ephemeral untuk pairing code
    crypto::KeyPair signed_prekey;
    std::uint32_t signed_prekey_id{1};
    Bytes signed_prekey_sig;            // XEdDSA(identity, 0x05 || signed_prekey.pub)
    std::uint32_t registration_id{0};
    Bytes adv_secret_key;               // 32 byte
    std::string pairing_code;
    std::string me_jid;                 // nomor@s.whatsapp.net, lalu user:device@s.whatsapp.net
    std::string platform;
    Bytes account;                      // ADVSignedDeviceIdentity lengkap
    bool registered{false};
};

Result<Creds> generate_creds();
Result<void> save_creds(const Creds& creds, const std::string& path);
Result<std::optional<Creds>> load_creds(const std::string& path);

}  // namespace wa
