#pragma once

#include "wa/common.hpp"

namespace wa::crypto {

struct KeyPair {
    Bytes priv;  // 32 byte
    Bytes pub;   // 32 byte
};

inline constexpr std::string_view kCrockford = "123456789ABCDEFGHJKLMNPQRSTVWXYZ";

Bytes random_bytes(std::size_t n);
void wipe(Bytes& b);

Bytes sha1(ByteView data);
Bytes sha256(ByteView data);
Bytes hmac_sha256(ByteView key, ByteView data);
Bytes hkdf_sha256(ByteView ikm, std::size_t length, ByteView salt = {}, ByteView info = {});

Result<Bytes> pbkdf2_sha256(ByteView password, ByteView salt, std::uint32_t iterations, std::size_t length);

// Hasil encrypt = ciphertext || tag(16). Input decrypt = ciphertext || tag(16).
Result<Bytes> aes256_gcm_encrypt(ByteView key, ByteView iv, ByteView plaintext, ByteView aad = {});
Result<Bytes> aes256_gcm_decrypt(ByteView key, ByteView iv, ByteView ciphertext, ByteView aad = {});
Result<Bytes> aes256_ctr(ByteView key, ByteView iv, ByteView data);  // enkripsi == dekripsi
Result<Bytes> aes256_cbc_decrypt(ByteView key, ByteView iv, ByteView ciphertext);  // padding PKCS7
Result<Bytes> aes256_cbc_encrypt(ByteView key, ByteView iv, ByteView plaintext);   // padding PKCS7

Result<KeyPair> x25519_generate();
Result<Bytes> x25519_public(ByteView priv);
Result<Bytes> x25519_shared(ByteView priv, ByteView pub);

// --- pairing code ---
std::string generate_pairing_code();                 // 8 karakter Crockford (40 bit acak)
bool is_valid_pairing_code(std::string_view code);
Result<Bytes> derive_pairing_key(std::string_view code, ByteView salt);  // PBKDF2-SHA256, 2<<16 iterasi
// salt(32) || iv(16) || AES-256-CTR(ephemeral_pub)
Result<Bytes> wrap_companion_ephemeral(std::string_view code, ByteView ephemeral_pub);

}  // namespace wa::crypto
