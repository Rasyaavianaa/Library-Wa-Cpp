#include "wa/binary.hpp"

#include <zlib.h>

#include <cctype>
#include <span>
#include <stdexcept>
#include <unordered_map>

#include "wa/tokens.inc"

namespace wa::binary {
namespace {

constexpr std::uint8_t kListEmpty = 0;
constexpr std::uint8_t kStreamEnd = 2;
constexpr std::uint8_t kDictionary0 = 236;
constexpr std::uint8_t kAdJid = 247;
constexpr std::uint8_t kList8 = 248;
constexpr std::uint8_t kList16 = 249;
constexpr std::uint8_t kJidPair = 250;
constexpr std::uint8_t kHex8 = 251;
constexpr std::uint8_t kBinary8 = 252;
constexpr std::uint8_t kBinary20 = 253;
constexpr std::uint8_t kBinary32 = 254;
constexpr std::uint8_t kNibble8 = 255;
constexpr std::size_t kPackedMax = 127;
constexpr int kMaxDepth = 64;
constexpr std::size_t kMaxInflated = 64u * 1024u * 1024u;

struct DecodeError : std::runtime_error {
    using std::runtime_error::runtime_error;
};

// ----------------------------------------------------------- token tables ---

std::span<const char* const> single_tokens() { return tokens::kSingle; }

std::span<const char* const> dictionary(std::size_t i) {
    switch (i) {
        case 0: return tokens::kDouble0;
        case 1: return tokens::kDouble1;
        case 2: return tokens::kDouble2;
        case 3: return tokens::kDouble3;
        default: return {};
    }
}

struct TokenEntry {
    int dict;  // -1 = single byte
    int index;
};

const std::unordered_map<std::string_view, TokenEntry>& token_map() {
    static const auto map = [] {
        std::unordered_map<std::string_view, TokenEntry> m;
        const auto s = single_tokens();
        for (std::size_t i = 0; i < s.size(); ++i) m.insert_or_assign(std::string_view(s[i]), TokenEntry{-1, static_cast<int>(i)});
        for (std::size_t d = 0; d < 4; ++d) {
            const auto t = dictionary(d);
            for (std::size_t i = 0; i < t.size(); ++i)
                m.insert_or_assign(std::string_view(t[i]), TokenEntry{static_cast<int>(d), static_cast<int>(i)});
        }
        return m;
    }();
    return map;
}

// ---------------------------------------------------------------- encoder ---

bool is_nibble(std::string_view s) {
    if (s.empty() || s.size() > kPackedMax) return false;
    for (const char c : s)
        if (!((c >= '0' && c <= '9') || c == '-' || c == '.')) return false;
    return true;
}

bool is_hex(std::string_view s) {
    if (s.empty() || s.size() > kPackedMax) return false;
    for (const char c : s)
        if (!((c >= '0' && c <= '9') || (c >= 'A' && c <= 'F'))) return false;
    return true;
}

class Encoder {
public:
    Encoder() { out_.push_back(0); }  // byte flag
    Bytes take() { return std::move(out_); }

    void node(const Node& n) {
        const bool has_content = !std::holds_alternative<std::monostate>(n.content);
        list_start(2 * n.attrs.size() + 1 + (has_content ? 1 : 0));
        string(n.tag);
        for (const auto& [k, v] : n.attrs) {
            string(k);
            string(v);
        }
        if (const auto* kids = std::get_if<NodeList>(&n.content)) {
            list_start(kids->size());
            for (const auto& c : *kids) node(c);
        } else if (const auto* t = std::get_if<std::string>(&n.content)) {
            string(*t);
        } else if (const auto* d = std::get_if<Bytes>(&n.content)) {
            byte_length(d->size());
            out_.insert(out_.end(), d->begin(), d->end());
        }
    }

private:
    void list_start(std::size_t n) {
        if (n == 0) {
            out_.push_back(kListEmpty);
        } else if (n < 256) {
            out_.push_back(kList8);
            out_.push_back(static_cast<std::uint8_t>(n));
        } else {
            out_.push_back(kList16);
            out_.push_back(static_cast<std::uint8_t>(n >> 8));
            out_.push_back(static_cast<std::uint8_t>(n & 0xFF));
        }
    }

    void byte_length(std::size_t n) {
        if (n < 256) {
            out_.push_back(kBinary8);
            out_.push_back(static_cast<std::uint8_t>(n));
        } else if (n < (std::size_t{1} << 20)) {
            out_.push_back(kBinary20);
            out_.push_back(static_cast<std::uint8_t>((n >> 16) & 0x0F));
            out_.push_back(static_cast<std::uint8_t>((n >> 8) & 0xFF));
            out_.push_back(static_cast<std::uint8_t>(n & 0xFF));
        } else {
            out_.push_back(kBinary32);
            for (int i = 3; i >= 0; --i) out_.push_back(static_cast<std::uint8_t>((n >> (8 * i)) & 0xFF));
        }
    }

    void raw(std::string_view s) {
        byte_length(s.size());
        const auto v = view_of(s);
        out_.insert(out_.end(), v.begin(), v.end());
    }

    static std::uint8_t pack(char c) {
        if (c >= '0' && c <= '9') return static_cast<std::uint8_t>(c - '0');
        if (c == '-') return 10;
        if (c == '.') return 11;
        if (c >= 'A' && c <= 'F') return static_cast<std::uint8_t>(10 + (c - 'A'));
        return 15;
    }

    void packed(std::string_view s, std::uint8_t type) {
        out_.push_back(type);
        std::uint8_t rounded = static_cast<std::uint8_t>((s.size() + 1) / 2);
        if (s.size() % 2 != 0) rounded |= 128;
        out_.push_back(rounded);
        std::size_t i = 0;
        for (; i + 1 < s.size(); i += 2) out_.push_back(static_cast<std::uint8_t>((pack(s[i]) << 4) | pack(s[i + 1])));
        if (i < s.size()) out_.push_back(static_cast<std::uint8_t>((pack(s[i]) << 4) | 15));
    }

    bool jid(std::string_view s) {
        const auto at = s.find('@');
        if (at == std::string_view::npos) return false;
        const std::string_view server = s.substr(at + 1);
        std::string_view user_combined = s.substr(0, at);
        std::optional<int> device;
        if (const auto colon = user_combined.find(':'); colon != std::string_view::npos) {
            int dev = 0;
            for (const char c : user_combined.substr(colon + 1)) {
                if (c < '0' || c > '9') return false;
                dev = dev * 10 + (c - '0');
            }
            device = dev;
            user_combined = user_combined.substr(0, colon);
        }
        std::string_view user = user_combined;
        if (const auto us = user.find('_'); us != std::string_view::npos) user = user.substr(0, us);

        if (device) {
            std::uint8_t domain = 0;
            if (server == "lid") domain = 1;
            else if (server == "hosted") domain = 128;
            else if (server == "hosted.lid") domain = 129;
            out_.push_back(kAdJid);
            out_.push_back(domain);
            out_.push_back(static_cast<std::uint8_t>(*device));
            string(user);
        } else {
            out_.push_back(kJidPair);
            if (!user.empty()) string(user);
            else out_.push_back(kListEmpty);
            string(server);
        }
        return true;
    }

    void string(std::string_view s) {
        if (s.empty()) {
            out_.push_back(0);
            return;
        }
        const auto& map = token_map();
        if (const auto it = map.find(s); it != map.end()) {
            if (it->second.dict >= 0) out_.push_back(static_cast<std::uint8_t>(kDictionary0 + it->second.dict));
            out_.push_back(static_cast<std::uint8_t>(it->second.index));
            return;
        }
        if (is_nibble(s)) return packed(s, kNibble8);
        if (is_hex(s)) return packed(s, kHex8);
        if (jid(s)) return;
        raw(s);
    }

    Bytes out_;
};

// ---------------------------------------------------------------- decoder ---

class Decoder {
public:
    explicit Decoder(ByteView d) : d_(d) {}

    Node node() {
        if (++depth_ > kMaxDepth) throw DecodeError("node terlalu dalam");
        const std::size_t list_size = read_list_size(byte());
        const std::uint8_t descr = byte();
        if (descr == kStreamEnd) throw DecodeError("stream end tak terduga");
        Node n;
        n.tag = read_string(descr);
        if (list_size == 0 || n.tag.empty()) throw DecodeError("node tidak valid");

        const std::size_t attr_count = (list_size - 1) >> 1;
        for (std::size_t i = 0; i < attr_count; ++i) {
            std::string key = read_string(byte());
            std::string value = read_string(byte());
            n.attrs.emplace_back(std::move(key), std::move(value));
        }
        if (list_size % 2 == 0) {
            const std::uint8_t tag = byte();
            if (tag == kListEmpty || tag == kList8 || tag == kList16) {
                const std::size_t count = read_list_size(tag);
                if (count > d_.size() - pos_) throw DecodeError("jumlah anak tidak masuk akal");
                NodeList kids;
                kids.reserve(count);
                for (std::size_t i = 0; i < count; ++i) kids.push_back(node());
                n.content = std::move(kids);
            } else if (tag == kBinary8) {
                const auto v = take(byte());
                n.content = Bytes(v.begin(), v.end());
            } else if (tag == kBinary20) {
                const auto v = take(int20());
                n.content = Bytes(v.begin(), v.end());
            } else if (tag == kBinary32) {
                const auto v = take(int_be(4));
                n.content = Bytes(v.begin(), v.end());
            } else {
                n.content = read_string(tag);
            }
        }
        --depth_;
        return n;
    }

private:
    void need(std::size_t n) const {
        if (n > d_.size() - pos_) throw DecodeError("data biner terpotong");
    }
    std::uint8_t byte() {
        need(1);
        return d_[pos_++];
    }
    ByteView take(std::size_t n) {
        need(n);
        const auto v = d_.subspan(pos_, n);
        pos_ += n;
        return v;
    }
    std::uint32_t int_be(int n) {
        std::uint32_t v = 0;
        for (int i = 0; i < n; ++i) v = (v << 8) | byte();
        return v;
    }
    std::uint32_t int20() {
        const std::uint32_t a = byte();
        const std::uint32_t b = byte();
        const std::uint32_t c = byte();
        return ((a & 15u) << 16) | (b << 8) | c;
    }
    std::string chars(std::size_t n) {
        const auto v = take(n);
        return std::string(v.begin(), v.end());
    }

    std::size_t read_list_size(std::uint8_t tag) {
        if (tag == kListEmpty) return 0;
        if (tag == kList8) return byte();
        if (tag == kList16) return int_be(2);
        throw DecodeError("tag list tidak valid");
    }

    static std::string unpack(std::uint8_t tag, std::uint8_t v) {
        if (tag == kHex8) {
            if (v > 15) throw DecodeError("nilai hex tidak valid");
            return std::string(1, "0123456789ABCDEF"[v]);
        }
        if (v <= 9) return std::string(1, static_cast<char>('0' + v));
        if (v == 10) return "-";
        if (v == 11) return ".";
        if (v == 15) return std::string(1, '\0');
        throw DecodeError("nilai nibble tidak valid");
    }

    std::string packed(std::uint8_t tag) {
        const std::uint8_t start = byte();
        std::string value;
        for (int i = 0; i < (start & 127); ++i) {
            const std::uint8_t cur = byte();
            value += unpack(tag, static_cast<std::uint8_t>((cur & 0xF0) >> 4));
            value += unpack(tag, static_cast<std::uint8_t>(cur & 0x0F));
        }
        if ((start >> 7) != 0 && !value.empty()) value.pop_back();
        return value;
    }

    std::string read_string(std::uint8_t tag) {
        const auto s = single_tokens();
        if (tag >= 1 && tag < s.size()) return s[tag];
        if (tag >= kDictionary0 && tag < kDictionary0 + 4) {
            const auto dict = dictionary(tag - kDictionary0);
            const std::size_t idx = byte();
            if (idx >= dict.size()) throw DecodeError("indeks token ganda di luar batas");
            return dict[idx];
        }
        switch (tag) {
            case kListEmpty: return {};
            case kBinary8: return chars(byte());
            case kBinary20: return chars(int20());
            case kBinary32: return chars(int_be(4));
            case kJidPair: {
                std::string user = read_string(byte());
                std::string server = read_string(byte());
                if (server.empty()) throw DecodeError("jid pair tanpa server");
                return user + "@" + server;
            }
            case kAdJid: {
                const std::uint8_t domain = byte();
                const std::uint8_t device = byte();
                const std::string user = read_string(byte());
                const char* server = "s.whatsapp.net";
                if (domain == 1) server = "lid";
                else if (domain == 128) server = "hosted";
                else if (domain == 129) server = "hosted.lid";
                std::string out = user;
                if (device != 0) out += ":" + std::to_string(device);
                return out + "@" + server;
            }
            case kHex8:
            case kNibble8: return packed(tag);
            default: throw DecodeError("tag string tidak dikenal: " + std::to_string(tag));
        }
    }

    ByteView d_;
    std::size_t pos_{0};
    int depth_{0};
};

Result<Bytes> inflate_zlib(ByteView in) {
    z_stream zs{};
    if (inflateInit(&zs) != Z_OK) return fail("zlib: init gagal", ErrorCode::protocol);
    zs.next_in = const_cast<Bytef*>(in.data());
    zs.avail_in = static_cast<uInt>(in.size());
    Bytes out;
    Bytes chunk(16384);
    int rc = Z_OK;
    do {
        zs.next_out = chunk.data();
        zs.avail_out = static_cast<uInt>(chunk.size());
        rc = inflate(&zs, Z_NO_FLUSH);
        if (rc != Z_OK && rc != Z_STREAM_END) {
            inflateEnd(&zs);
            return fail("zlib: dekompresi gagal", ErrorCode::protocol);
        }
        out.insert(out.end(), chunk.begin(), chunk.begin() + static_cast<std::ptrdiff_t>(chunk.size() - zs.avail_out));
        if (out.size() > kMaxInflated) {
            inflateEnd(&zs);
            return fail("zlib: hasil terlalu besar", ErrorCode::protocol);
        }
        if (rc == Z_OK && zs.avail_in == 0 && zs.avail_out != 0) {
            inflateEnd(&zs);
            return fail("zlib: data terpotong", ErrorCode::protocol);
        }
    } while (rc != Z_STREAM_END);
    inflateEnd(&zs);
    return out;
}

}  // namespace

// ------------------------------------------------------------ Node helpers ---

std::optional<std::string_view> Node::attr(std::string_view key) const {
    for (const auto& [k, v] : attrs)
        if (k == key) return std::string_view(v);
    return std::nullopt;
}

const NodeList* Node::children() const { return std::get_if<NodeList>(&content); }
const Bytes* Node::data() const { return std::get_if<Bytes>(&content); }

const Node* Node::child(std::string_view child_tag) const {
    if (const auto* kids = children())
        for (const auto& c : *kids)
            if (c.tag == child_tag) return &c;
    return nullptr;
}

const std::string* Node::str() const { return std::get_if<std::string>(&content); }

Bytes Node::payload() const {
    if (const auto* d = data()) return *d;
    if (const auto* t = str()) return to_bytes(*t);
    return {};
}

std::string Node::text() const {
    if (const auto* t = str()) return *t;
    if (const auto* d = data()) return to_string(*d);
    return {};
}

Node make_node(std::string tag, Attrs attrs) {
    Node n;
    n.tag = std::move(tag);
    n.attrs = std::move(attrs);
    return n;
}

Node make_node(std::string tag, Attrs attrs, NodeList children) {
    Node n = make_node(std::move(tag), std::move(attrs));
    n.content = std::move(children);
    return n;
}

Node make_node(std::string tag, Attrs attrs, Bytes data) {
    Node n = make_node(std::move(tag), std::move(attrs));
    n.content = std::move(data);
    return n;
}

Node make_text_node(std::string tag, Attrs attrs, std::string text) {
    Node n = make_node(std::move(tag), std::move(attrs));
    n.content = std::move(text);
    return n;
}

Bytes encode(const Node& node) {
    Encoder enc;
    enc.node(node);
    return enc.take();
}

Result<Node> decode(ByteView frame) {
    if (frame.empty()) return fail("frame biner kosong", ErrorCode::protocol);
    const std::uint8_t flags = frame[0];
    ByteView body = frame.subspan(1);
    Bytes inflated;
    if (flags & 2) {
        auto r = inflate_zlib(body);
        if (!r) return std::unexpected(r.error());
        inflated = std::move(*r);
        body = inflated;
    }
    try {
        Decoder d(body);
        return d.node();
    } catch (const DecodeError& e) {
        return fail(std::string("decode biner: ") + e.what(), ErrorCode::protocol);
    } catch (const std::exception& e) {
        return fail(std::string("decode biner: ") + e.what(), ErrorCode::protocol);
    }
}

std::string dump(const Node& n, int indent) {
    const std::string pad(static_cast<std::size_t>(indent) * 2, ' ');
    std::string s = pad + "<" + n.tag;
    for (const auto& [k, v] : n.attrs) s += " " + k + "=\"" + v + "\"";
    if (const auto* kids = n.children()) {
        s += ">\n";
        for (const auto& c : *kids) s += dump(c, indent + 1);
        s += pad + "</" + n.tag + ">\n";
    } else if (const auto* t = n.str()) {
        s += ">" + *t + "</" + n.tag + ">\n";
    } else if (const auto* d = n.data()) {
        s += "> [" + std::to_string(d->size()) + " byte] ";
        const std::size_t shown = std::min<std::size_t>(d->size(), 32);
        s += to_hex(ByteView(d->data(), shown));
        s += "\n";
    } else {
        s += "/>\n";
    }
    return s;
}

}  // namespace wa::binary
