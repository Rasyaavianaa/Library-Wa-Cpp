#include <algorithm>

#include "wa/signal.hpp"
#include "wa/xeddsa.hpp"

namespace wa::sig {
namespace {

constexpr std::size_t kMaxSessions = 20;

Bytes prefixed(ByteView raw) {
    Bytes out;
    out.reserve(raw.size() + 1);
    out.push_back(0x05);
    out.insert(out.end(), raw.begin(), raw.end());
    return out;
}

Bytes slice(const Bytes& b, std::size_t off, std::size_t n) {
    return Bytes(b.begin() + static_cast<std::ptrdiff_t>(off), b.begin() + static_cast<std::ptrdiff_t>(off + n));
}

Bytes kdf(ByteView input, ByteView salt, std::string_view info, std::size_t length) {
    return crypto::hkdf_sha256(input, length, salt, view_of(info));
}

Bytes hmac_byte(ByteView key, std::uint8_t value) { return crypto::hmac_sha256(key, ByteView(&value, 1)); }

}  // namespace

bool Cipher::has_session(const std::string& address) {
    const auto& list = store_.sessions(address);
    return std::any_of(list.begin(), list.end(), [](const Session& s) { return s.open; });
}

// X3DH sisi inisiator. secret = 0xFF*32 || DH(IK_A,SPK_B) || DH(EK_A,IK_B) || DH(EK_A,SPK_B) [|| DH(EK_A,OPK_B)]
Result<void> Cipher::init_outgoing(const std::string& address, const PreKeyBundle& b) {
    if (b.identity.size() != 32 || b.signed_pub.size() != 32 || b.signed_sig.size() != 64)
        return fail("bundel prekey tidak valid (ukuran kunci)", ErrorCode::protocol);
    if (b.has_prekey && b.prekey_pub.size() != 32) return fail("prekey sekali pakai tidak valid", ErrorCode::protocol);
    if (!crypto::xeddsa_verify(b.identity, prefixed(b.signed_pub), b.signed_sig))
        return fail("tanda tangan signed prekey tidak valid", ErrorCode::crypto);

    auto base = crypto::x25519_generate();
    auto ratchet = crypto::x25519_generate();
    if (!base) return std::unexpected(base.error());
    if (!ratchet) return std::unexpected(ratchet.error());

    auto dh1 = crypto::x25519_shared(creds_.identity_key.priv, b.signed_pub);
    auto dh2 = crypto::x25519_shared(base->priv, b.identity);
    auto dh3 = crypto::x25519_shared(base->priv, b.signed_pub);
    if (!dh1) return std::unexpected(dh1.error());
    if (!dh2) return std::unexpected(dh2.error());
    if (!dh3) return std::unexpected(dh3.error());

    Bytes secret(32, 0xFF);
    secret.insert(secret.end(), dh1->begin(), dh1->end());
    secret.insert(secret.end(), dh2->begin(), dh2->end());
    secret.insert(secret.end(), dh3->begin(), dh3->end());
    if (b.has_prekey) {
        auto dh4 = crypto::x25519_shared(base->priv, b.prekey_pub);
        if (!dh4) return std::unexpected(dh4.error());
        secret.insert(secret.end(), dh4->begin(), dh4->end());
    }
    const Bytes okm = kdf(secret, Bytes(32, 0), "WhisperText", 64);
    const Bytes root0 = slice(okm, 0, 32);

    // rantai pengirim pertama: DH(ratchet baru kita, signed prekey lawan)
    auto dh5 = crypto::x25519_shared(ratchet->priv, b.signed_pub);
    if (!dh5) return std::unexpected(dh5.error());
    const Bytes okm2 = kdf(*dh5, root0, "WhisperRatchet", 64);

    Session s;
    s.remote_identity = b.identity;
    s.base_key = base->pub;
    s.root_key = slice(okm2, 0, 32);
    s.our_ratchet = *ratchet;
    s.last_remote_ratchet = b.signed_pub;
    s.registration_id = b.registration_id;
    s.open = true;

    Chain send;
    send.ratchet_key = ratchet->pub;
    send.chain_key = slice(okm2, 32, 32);
    send.index = -1;
    send.sending = true;
    s.chains.push_back(std::move(send));

    s.pending.active = true;
    s.pending.signed_id = b.signed_id;
    s.pending.has_prekey = b.has_prekey;
    s.pending.prekey_id = b.prekey_id;
    s.pending.base_key = base->pub;

    auto& list = store_.sessions(address);
    for (auto& old : list) old.open = false;
    list.insert(list.begin(), std::move(s));
    if (list.size() > kMaxSessions) list.pop_back();
    return {};
}

Result<Encrypted> Cipher::encrypt(const std::string& address, ByteView plaintext) {
    auto& list = store_.sessions(address);
    Session* live = nullptr;
    for (auto& c : list) {
        if (c.open) {
            live = &c;
            break;
        }
    }
    if (!live) return fail("tidak ada sesi terbuka untuk " + address, ErrorCode::protocol);

    Session work = *live;  // atomik: dipakai hanya bila semua langkah berhasil
    Chain* chain = nullptr;
    for (auto& c : work.chains) {
        if (c.sending && std::ranges::equal(c.ratchet_key, work.our_ratchet.pub)) {
            chain = &c;
            break;
        }
    }
    if (!chain) return fail("rantai pengirim tidak ditemukan", ErrorCode::crypto);

    const Bytes seed = hmac_byte(chain->chain_key, 0x01);
    chain->chain_key = hmac_byte(chain->chain_key, 0x02);
    chain->index += 1;
    const auto counter = static_cast<std::uint32_t>(chain->index);

    const Bytes okm = kdf(seed, Bytes(32, 0), "WhisperMessageKeys", 96);
    const Bytes cipher_key = slice(okm, 0, 32);
    const Bytes mac_key = slice(okm, 32, 32);
    const Bytes iv = slice(okm, 64, 16);
    auto ct = crypto::aes256_cbc_encrypt(cipher_key, iv, plaintext);
    if (!ct) return std::unexpected(ct.error());

    pb::Writer w;
    w.bytes(1, prefixed(work.our_ratchet.pub)).varint(2, counter).varint(3, work.previous_counter).bytes(4, *ct);
    const Bytes proto = w.take();
    const Bytes version{0x33};

    // MAC = HMAC(mac_key, ourIdentity(33) || theirIdentity(33) || versi || proto)[0..8]
    const Bytes mac_input = concat({prefixed(creds_.identity_key.pub), prefixed(work.remote_identity), version, proto});
    Bytes mac = crypto::hmac_sha256(mac_key, mac_input);
    mac.resize(8);
    const Bytes whisper = concat({version, proto, mac});

    Encrypted out;
    if (work.pending.active) {
        pb::Writer pk;
        if (work.pending.has_prekey) pk.varint(1, work.pending.prekey_id);
        pk.bytes(2, prefixed(work.pending.base_key))
            .bytes(3, prefixed(creds_.identity_key.pub))
            .bytes(4, whisper)
            .varint(5, creds_.registration_id)
            .varint(6, work.pending.signed_id);
        out.data = concat({version, pk.data()});
        out.prekey_message = true;
    } else {
        out.data = whisper;
    }
    *live = std::move(work);
    return out;
}

}  // namespace wa::sig
