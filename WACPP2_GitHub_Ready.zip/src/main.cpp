#include <algorithm>
#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <iostream>

#include "wa/binary.hpp"
#include "wa/client.hpp"
#include "wa/common.hpp"
#include "wa/xeddsa.hpp"
#include "wa/crypto.hpp"
#include "wa/noise.hpp"
#include "wa/ws.hpp"

namespace {

int g_failed = 0;

void check(bool ok, std::string_view name) {
    std::cout << (ok ? "[PASS] " : "[FAIL] ") << name << '\n';
    if (!ok) ++g_failed;
}

wa::Bytes hex(std::string_view s) {
    auto r = wa::from_hex(s);
    return r ? *r : wa::Bytes{};
}

int run_selftest() {
    using namespace wa;

    check(to_hex(crypto::sha256(view_of("abc"))) == "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad",
          "sha256(abc)");

    {  // RFC 5869 test case 1
        const Bytes ikm(22, 0x0b);
        const Bytes okm = crypto::hkdf_sha256(ikm, 42, hex("000102030405060708090a0b0c"), hex("f0f1f2f3f4f5f6f7f8f9"));
        check(to_hex(okm) == "3cb25f25faacd57a90434f64d0362f2a2d2d0a90cf1a5a4c5db02d56ecc4c5bf34007208d5b887185865",
              "hkdf-sha256 (RFC 5869 #1)");
    }
    {
        auto k = crypto::pbkdf2_sha256(view_of("password"), view_of("salt"), 1, 32);
        check(k && to_hex(*k) == "120fb6cffcf8b32c43e7225256c4f837a86548c92ccc35480805987cb70be17b", "pbkdf2-sha256");
    }
    {  // RFC 7748 section 6.1
        const Bytes a_priv = hex("77076d0a7318a57d3c16c17251b26645df4c2f87ebc0992ab177fba51db92c2a");
        const Bytes a_pub = hex("8520f0098930a754748b7ddcb43ef75a0dbf3a0d26381af4eba4a98eaa9b4e6a");
        const Bytes b_priv = hex("5dab087e624a8a4b79e17f8b83800ee66f3bb1292618b6fd1c2f8b27ff88e0eb");
        const Bytes b_pub = hex("de9edb7d7b7dc1b4d35b61c2ece435373f8343c85b78674dadfc7e146f882b4f");
        const std::string shared = "4a5d9d5ba4ce2de1728e3bf480350f25e07e21c947d19e3376f09b3c1e161742";
        auto pa = crypto::x25519_public(a_priv);
        auto s1 = crypto::x25519_shared(a_priv, b_pub);
        auto s2 = crypto::x25519_shared(b_priv, a_pub);
        check(pa && *pa == a_pub, "x25519 public dari private");
        check(s1 && s2 && to_hex(*s1) == shared && to_hex(*s2) == shared, "x25519 shared secret (RFC 7748)");
    }
    {
        const Bytes key = crypto::random_bytes(32);
        const Bytes iv = crypto::random_bytes(12);
        const Bytes aad = to_bytes("aad");
        auto ct = crypto::aes256_gcm_encrypt(key, iv, view_of("halo wa"), aad);
        auto pt = ct ? crypto::aes256_gcm_decrypt(key, iv, *ct, aad) : fail("x");
        check(ct && pt && to_string(*pt) == "halo wa", "aes-256-gcm roundtrip");
        if (ct) {
            Bytes bad = *ct;
            bad[0] ^= 1;
            check(!crypto::aes256_gcm_decrypt(key, iv, bad, aad), "aes-256-gcm menolak data yang diubah");
        }
    }
    {
        auto dec = base64_decode(base64_encode(view_of("pairing-code!")));
        check(dec && to_string(*dec) == "pairing-code!", "base64 roundtrip");
    }
    {
        const std::string code = crypto::generate_pairing_code();
        auto kp = crypto::x25519_generate();
        auto wrapped = kp ? crypto::wrap_companion_ephemeral(code, kp->pub) : fail("x");
        check(crypto::is_valid_pairing_code(code) && wrapped && wrapped->size() == 80, "pairing code + wrap ephemeral (80 byte)");
        std::cout << "       contoh pairing code: " << code << '\n';
    }
    {
        using namespace wa::binary;
        const Node n = make_node("iq",
                                 {{"to", "s.whatsapp.net"}, {"type", "get"}, {"xmlns", "w:p"}, {"id", "12345"},
                                  {"jid", "6281234567890@s.whatsapp.net"}},
                                 NodeList{make_node("ping"), make_node("enc", {{"v", "2"}}, Bytes{1, 2, 3, 4})});
        auto back = decode(encode(n));
        const bool ok = back && back->tag == "iq" && back->attr("id") == "12345" &&
                        back->attr("jid") == "6281234567890@s.whatsapp.net" && back->child("ping") != nullptr &&
                        back->child("enc") && back->child("enc")->data() && back->child("enc")->data()->size() == 4;
        check(ok, "codec biner WABinary roundtrip");
        if (!ok && !back) std::cout << "       " << back.error().message << '\n';
    }
    {
        bool all_ok = true;
        bool tamper_ok = true;
        for (int i = 0; i < 16; ++i) {
            auto kp = crypto::x25519_generate();
            const Bytes msg = to_bytes("pesan uji xeddsa");
            auto sig = kp ? crypto::xeddsa_sign(kp->priv, msg) : fail("x");
            if (!kp || !sig || sig->size() != 64 || !crypto::xeddsa_verify(kp->pub, msg, *sig)) all_ok = false;
            if (kp && sig && crypto::xeddsa_verify(kp->pub, to_bytes("pesan lain"), *sig)) tamper_ok = false;
        }
        check(all_ok, "xeddsa sign/verify (16 kunci acak)");
        check(tamper_ok, "xeddsa menolak pesan yang diubah");
    }
    {
        auto c = generate_creds();
        std::string why;
        bool ok = c.has_value();
        if (ok) {
            Bytes m{0x05};
            m.insert(m.end(), c->signed_prekey.pub.begin(), c->signed_prekey.pub.end());
            ok = crypto::xeddsa_verify(c->identity_key.pub, m, c->signed_prekey_sig);
        }
        check(ok, "signed prekey ditandatangani identity key");
    }
    {
        const Bytes padded{1, 2, 3, 3, 3, 3};
        auto u = unpad_random_max16(padded);
        check(u && u->size() == 3, "unpad pesan WA");
    }
    {
        pb::Writer w1;
        w1.string(1, "halo dunia");
        const IncomingMessage m1 = parse_message(w1.data());
        pb::Writer inner;
        inner.string(1, "teks panjang");
        pb::Writer w2;
        w2.message(6, inner);
        const IncomingMessage m2 = parse_message(w2.data());
        check(m1.kind == "text" && m1.text == "halo dunia" && m2.kind == "text" && m2.text == "teks panjang",
              "parser protobuf Message (teks)");
    }
    {
        const std::string path = "selftest_store.tmp";
        bool ok = false;
        {
            sig::Store a(path);
            a.generate_prekeys(3);
            sig::Session s;
            s.remote_identity = crypto::random_bytes(32);
            s.base_key = crypto::random_bytes(32);
            s.root_key = crypto::random_bytes(32);
            auto rk = crypto::x25519_generate();
            if (rk) s.our_ratchet = *rk;
            s.last_remote_ratchet = crypto::random_bytes(32);
            s.previous_counter = 7;
            s.registration_id = 123;
            sig::Chain c;
            c.ratchet_key = crypto::random_bytes(32);
            c.chain_key = crypto::random_bytes(32);
            c.index = 4;
            c.skipped.push_back({2, crypto::random_bytes(32)});
            s.chains.push_back(c);
            a.sessions("628@s.whatsapp.net:1").push_back(s);
            const bool saved = a.save().has_value();
            sig::Store b(path);
            const bool loaded = b.load().has_value();
            auto& got = b.sessions("628@s.whatsapp.net:1");
            ok = saved && loaded && b.prekey_count() == 3 && got.size() == 1 && got[0].base_key == s.base_key &&
                 got[0].root_key == s.root_key && got[0].our_ratchet.priv == s.our_ratchet.priv &&
                 got[0].previous_counter == 7 && got[0].chains.size() == 1 && got[0].chains[0].index == 4 &&
                 got[0].chains[0].skipped.size() == 1 && got[0].chains[0].skipped[0].seed == c.skipped[0].seed;
        }
        std::remove(path.c_str());
        check(ok, "penyimpanan sesi + prekey (simpan/muat)");
    }
    {
        const Bytes padded = outbound::pad_random_max16(view_of("halo"));
        auto u = unpad_random_max16(padded);
        const IncomingMessage m = parse_message(outbound::build_text_message("teks keluar"));
        const auto jid = outbound::normalize_jid("+62 800-0000-0000");
        const auto parts = outbound::split_jid("6280000000000:35@s.whatsapp.net");
        check(u && to_string(*u) == "halo" && m.kind == "text" && m.text == "teks keluar" &&
                  jid == "6280000000000@s.whatsapp.net" && parts && parts->device == 35 && parts->user == "6280000000000",
              "pad/unpad, pesan teks keluar, normalisasi JID");
    }
    {
        auto alice = generate_creds();
        auto bob = generate_creds();
        bool ok = alice.has_value() && bob.has_value();
        if (ok) {
            sig::Store as("st_a.tmp");
            sig::Store bs("st_b.tmp");
            sig::Cipher ca(as, *alice);
            sig::Cipher cb(bs, *bob);
            const auto otk = bs.generate_prekeys(1);
            sig::PreKeyBundle b;
            b.jid = "bob";
            b.registration_id = bob->registration_id;
            b.identity = bob->identity_key.pub;
            b.signed_id = bob->signed_prekey_id;
            b.signed_pub = bob->signed_prekey.pub;
            b.signed_sig = bob->signed_prekey_sig;
            b.has_prekey = !otk.empty();
            if (b.has_prekey) {
                b.prekey_id = otk[0].id;
                b.prekey_pub = otk[0].pair.pub;
            }
            ok = ca.init_outgoing("bob", b).has_value();
            auto m1 = ca.encrypt("bob", view_of("satu"));
            auto m2 = ca.encrypt("bob", view_of("dua"));
            auto m3 = ca.encrypt("bob", view_of("tiga"));
            ok = ok && m1 && m2 && m3 && m1->prekey_message && m3->prekey_message;
            if (ok) {
                auto d3 = cb.decrypt("alice", "pkmsg", m3->data);  // tidak berurutan
                auto d1 = cb.decrypt("alice", "pkmsg", m1->data);
                auto d2 = cb.decrypt("alice", "pkmsg", m2->data);
                ok = d1 && d2 && d3 && to_string(*d1) == "satu" && to_string(*d2) == "dua" && to_string(*d3) == "tiga";
                auto r1 = cb.encrypt("alice", view_of("balasan"));
                auto dr = r1 ? ca.decrypt("bob", "msg", r1->data) : fail("x");
                ok = ok && r1 && !r1->prekey_message && dr && to_string(*dr) == "balasan";
                auto m4 = ca.encrypt("bob", view_of("empat"));
                auto d4 = m4 ? cb.decrypt("alice", "msg", m4->data) : fail("x");
                ok = ok && m4 && !m4->prekey_message && d4 && to_string(*d4) == "empat";
            }
        }
        check(ok, "signal: X3DH + Double Ratchet pengirim<->penerima (termasuk tidak berurutan)");
    }
    std::cout << (g_failed == 0 ? "\nsemua tes lulus\n" : "\nada tes gagal\n");
    return g_failed == 0 ? 0 : 1;
}

int run_handshake() {
    using namespace wa;
    WsClient ws;
    WsOptions opt;
    opt.headers = {{"Origin", "https://web.whatsapp.com"}, {"User-Agent", "Mozilla/5.0 (X11; Linux x86_64)"}};
    if (auto r = ws.connect("wss://web.whatsapp.com/ws/chat", opt); !r) {
        std::cerr << "connect gagal: " << r.error().message << '\n';
        return 1;
    }
    std::cout << "websocket + TLS terhubung\n";

    auto eph = crypto::x25519_generate();
    auto noise_key = crypto::x25519_generate();
    if (!eph || !noise_key) {
        std::cerr << "gagal membuat kunci\n";
        return 1;
    }
    NoiseSession ns(*eph);

    auto first = ns.frame(ns.client_hello());
    if (!first || !ws.send_binary(*first)) {
        std::cerr << "gagal kirim clientHello\n";
        return 1;
    }
    std::cout << "clientHello terkirim, menunggu serverHello...\n";

    std::vector<Bytes> frames;
    while (frames.empty()) {
        auto msg = ws.receive(15000);
        if (!msg) {
            std::cerr << "receive gagal: " << msg.error().message << '\n';
            return 1;
        }
        if (msg->op == WsOp::close) {
            std::cerr << "server menutup koneksi\n";
            return 1;
        }
        auto fr = ns.unframe(msg->data);
        if (!fr) {
            std::cerr << "unframe gagal: " << fr.error().message << '\n';
            return 1;
        }
        frames = std::move(*fr);
    }

    auto hello = NoiseSession::parse_server_hello(frames[0]);
    if (!hello) {
        std::cerr << "serverHello tidak valid: " << hello.error().message << '\n';
        return 1;
    }
    auto key_enc = ns.process_server_hello(*hello, *noise_key);
    if (!key_enc) {
        std::cerr << "noise handshake gagal: " << key_enc.error().message << '\n';
        return 1;
    }
    std::cout << "NOISE OK: tag GCM server cocok\n"
              << "  server static : " << to_hex(ns.server_static()) << '\n'
              << "  sertifikat    : " << ns.server_cert().size() << " byte\n"
              << "  noise key enc : " << key_enc->size() << " byte (siap jadi clientFinish.static)\n"
              << "Fase 2 menambah ClientPayload + pairing lalu mengirim clientFinish.\n";
    ws.close();
    return 0;
}

std::string trim_copy(std::string_view input) {
    std::size_t first = 0;
    while (first < input.size() && std::isspace(static_cast<unsigned char>(input[first]))) ++first;
    std::size_t last = input.size();
    while (last > first && std::isspace(static_cast<unsigned char>(input[last - 1]))) --last;
    return std::string(input.substr(first, last - first));
}

std::string lower_ascii(std::string value) {
    std::ranges::transform(value, value.begin(), [](unsigned char c) {
        return static_cast<char>(std::tolower(c));
    });
    return value;
}

// Mengubah JID chat pribadi menjadi alamat bare (tanpa device ':N').
// WhatsApp dapat mengirim identitas chat pribadi sebagai @s.whatsapp.net
// maupun @lid. Domain grup seperti @g.us sengaja tidak diterima di sini.
std::optional<std::string> direct_chat_recipient(std::string_view jid) {
    const auto parts = wa::outbound::split_jid(jid);
    if (!parts) return std::nullopt;
    if (parts->server != "s.whatsapp.net" && parts->server != "lid") return std::nullopt;
    return parts->user + "@" + parts->server;
}

std::string cpp_command_reply(std::string_view incoming) {
    const std::string text = lower_ascii(trim_copy(incoming));
    if (text == "cpp" || text == "cpp menu" || text == "cpp help") {
        return "🤖 WACPP2 MENU\n"
               "cpp menu  - tampilkan menu\n"
               "cpp ping  - cek bot aktif\n"
               "cpp status - cek runtime\n"
               "cpp about - info WACPP2\n\n"
               "Prefix command: cpp";
    }
    if (text == "cpp ping") return "Pong! WACPP2 aktif dan menerima pesan. ✅";
    if (text == "cpp status") return "WACPP2 runtime aktif. WhatsApp session sedang berjalan. ✅";
    if (text == "cpp about") return "WACPP2 adalah runtime WhatsApp berbasis C++ native. Media dan game engine belum diaktifkan.";
    return "Command tidak dikenal. Ketik: cpp menu";
}

int run_pair(int argc, char** argv, int first_option = 2, bool force_lifetime = false) {
    using namespace wa;
    ClientConfig cfg;
    std::string version_text;
    std::string send_to;
    std::string send_text;
    for (int i = first_option; i < argc; ++i) {
        const std::string a = argv[i];
        auto next = [&]() -> std::string { return i + 1 < argc ? std::string(argv[++i]) : std::string(); };
        if (a == "--phone") cfg.phone = next();
        else if (a == "--version") version_text = next();
        else if (a == "--creds") cfg.creds_path = next();
        else if (a == "--code") cfg.custom_code = next();
        else if (a == "--stay") cfg.stay_online = true;
        else if (a == "--store") cfg.store_path = next();
        else if (a == "--send") send_to = next();
        else if (a == "--text") send_text = next();
    }
    if (version_text.empty()) {
        std::cerr << "butuh --version 2.3000.<client_revision>\n";
        return 2;
    }
    auto v = parse_version(version_text);
    if (!v) {
        std::cerr << v.error().message << '\n';
        return 2;
    }
    cfg.version = *v;
    cfg.stay_online = cfg.stay_online || force_lifetime;
    cfg.lifetime_mode = force_lifetime;

    Client* active_client = nullptr;
    cfg.on_message = [&active_client](const IncomingMessage& m) {
        std::cout << "[PESAN] " << m.kind << " dari " << m.author << " (chat " << m.from << ") id=" << m.id;
        if (!m.text.empty()) std::cout << "\n        teks: " << m.text;
        std::cout << std::endl;

        if (!active_client || m.kind != "text" || m.category == "peer") return;
        const std::string command = trim_copy(m.text);
        std::string normalized = lower_ascii(command);
        if (normalized != "cpp" && !normalized.starts_with("cpp ")) return;

        // Balasan command hanya ditujukan ke chat pribadi. @lid juga dipakai
        // WhatsApp sebagai identitas chat pribadi; buang device suffix ':N'
        // agar tujuan yang masuk ke jalur usync/send adalah JID bare.
        // Group JID (@g.us) sengaja belum didukung pada versi ini.
        // Prioritaskan PN asli jika WhatsApp menyediakannya.
        const std::string& reply_jid = m.sender_pn.empty() ? m.from : m.sender_pn;
        const auto recipient = direct_chat_recipient(reply_jid);
        if (!recipient) {
            logf(LogLevel::warn, "command cpp dari chat non-pribadi belum dibalas: {}", m.from);
            return;
        }
        active_client->enqueue_text(*recipient, cpp_command_reply(command));
        logf(LogLevel::info, "command '{}' masuk antrean balasan untuk {}", command, *recipient);
    };
    cfg.on_pairing_code = [](std::string_view code) {
        std::cout << "\n==============================\n"
                  << "  KODE PAIRING:  " << code.substr(0, 4) << "-" << code.substr(4) << '\n'
                  << "==============================\n"
                  << "HP: WhatsApp > Perangkat tertaut > Tautkan perangkat >\n"
                  << "    Tautkan dengan nomor telepon saja > masukkan kode di atas.\n\n" << std::flush;
    };

    if (!send_to.empty()) {
        if (send_text.empty()) {
            std::cerr << "--send butuh --text \"isi pesan\"\n";
            return 2;
        }
        cfg.stay_online = true;
        cfg.exit_after_send = true;
        cfg.lifetime_mode = false;
        cfg.on_ready = [send_to, send_text](Client& c) { c.enqueue_text(send_to, send_text); };
    }
    Client client(std::move(cfg));
    active_client = &client;
    if (force_lifetime) {
        std::cout << "[WACPP2] Lifetime runtime aktif. Prefix WhatsApp: cpp\n"
                  << "[WACPP2] Kirim 'cpp menu' dari chat pribadi (@s.whatsapp.net atau @lid).\n";
    }
    auto r = client.run();
    if (!r) {
        std::cerr << "GAGAL: " << r.error().message << '\n';
        return 1;
    }
    std::cout << "SELESAI: login berhasil sebagai " << client.creds().me_jid << '\n';
    return 0;
}
}  // namespace

int main(int argc, char** argv) {
    if (const char* dbg = std::getenv("WA_DEBUG"); dbg && *dbg == '1') wa::log_level() = wa::LogLevel::debug;
    const std::string cmd = argc > 1 ? argv[1] : "";
    if (cmd == "selftest") return run_selftest();
    if (cmd == "handshake") return run_handshake();
    if (cmd == "pair") return run_pair(argc, argv, 2, false);
    if (cmd == "cpp") {
        const std::string sub = argc > 2 ? argv[2] : "";
        if (sub == "start") return run_pair(argc, argv, 3, true);
        if (sub == "pair") return run_pair(argc, argv, 3, false);
        if (sub == "selftest") return run_selftest();
        std::cout << "WACPP2 CLI\n"
                  << "  wacpp2 cpp start --version 2.3000.REV [--phone 628xx] [--creds creds.txt] [--store signal.txt]\n"
                  << "  wacpp2 cpp pair --version 2.3000.REV [--phone 628xx]\n"
                  << "  wacpp2 cpp selftest\n\n"
                  << "WhatsApp chat command prefix: cpp (contoh: cpp menu)\n";
        return sub.empty() || sub == "menu" || sub == "help" ? 0 : 1;
    }
    std::cout << "pemakaian: wacpp2 selftest | handshake | pair --phone 628xx --version 2.3000.REV [--code ABCD1234] [--creds file] [--stay] | cpp start --version 2.3000.REV\n";
    return cmd.empty() ? 0 : 1;
}
